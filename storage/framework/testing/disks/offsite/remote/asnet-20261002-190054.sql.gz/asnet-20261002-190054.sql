-- ASNet test dump
CREATE TABLE customers (id BIGINT);
INSERT INTO customers VALUES (1);
